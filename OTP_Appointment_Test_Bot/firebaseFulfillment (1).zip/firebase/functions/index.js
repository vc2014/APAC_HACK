// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion } = require('dialogflow-fulfillment');
const {BrowseCarousel, BrowseCarouselItem } = require('actions-on-google')
const host = 'samples.openweathermap.org';
const wwoApiKey = 'b6907d289e10d714a6e88b30761fae22';
const https = require('https');
const googleUrl = 'https://google.com';
const IMG_URL_AOG = 'https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png';

process.env.DEBUG = 'dialogflow:*'; // enables lib debugging statements


const {google} = require('googleapis');

// Enter your calendar ID below and service account JSON below, see https://github.com/dialogflow/bike-shop/blob/master/README.md#calendar-setup
const calendarId = 'u51lj28b50etl5v806c6qvobu4@group.calendar.google.com'; // looks like "6ujc6j6rgfk02cp02vg6h38cs0@group.calendar.google.com"

// Starts with {"type": "service_account",...
const serviceAccount = {"type": "service_account",
  "project_id": "testbot-38d85",
  "private_key_id": "fc48a8a0cddd017462e6bc488a74c0d0378e4fd9",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCXDANqqetIpYgW\ndokgNxPK4w24xy/4KEUxHaX0N3p5Dc/VeWiZq8i+VAMwvU+5lcEVB5BfgYKJHIvM\nlLYsN0cFTgGYU2sg001qUv2U8Z9WCynEUBedvAgh0DJ1cvbvnwiYIw+zJHRAXz3x\nybwL3BbfFSET1m+FiUlhOx2+mzhQVqNxxW7vVkgpWBIL1AmS+GhnQoKuTLPFTqXp\ncbC4bLQOCPmcgg3sSTwQuuEgpLBto/D5CSgqhGUbHHzIcph0HfgTLUreHbYr2cHo\nN5zYaqYbp/UDvzq4IuF8ki65Bx9eaWenAbC7jYwfXZa4ucIBba8wu2Knypj5SVHR\nOTAk5P9RAgMBAAECggEABfrgJ0DJK3//NGl2uhdoIZIN7OT465WXkK9cbr/kCccf\n1XMoLp5QFSXxFuTF02KACY+6OefAFeLTD5NLJ5K8LXP2SPQzg3IOKHGW78bFoMPS\nIF8t4i0rssACAWee6mN01QYdVOGydwp2QrxyhRMudiBJZhZJJcOmy7JKFg3h479M\nwRBIjK1VbbKPFqEq7+Rg3yNXRWiPqAvtuXDtLnENOOmI2x6Rzz7Wn6P222pjqBm9\nwBUN5Y7t/GXT1+6sG9+8RTaem2k1uWkA2snUg1OJHl6Mckq+bUsHU+K5aLFEnVor\nlnXRcfII7TeOs+n1Vnehvup6r5UeE6kL3duaWDetAQKBgQDRbJaYwvhTcaXahjoT\ns6L4qJ4M14eBTOEghlv9Sp5g+/c/26x/S178VExZkueQRsde1cEWd/G+Bsq/glZ5\n2kQxuBRUbURsS0EuYN5LB5mbQimPKgI2ZBvlwcJBKO1BmoTkIllsJoEe1r5bDStP\nAcjSOkqftK6BYAsn6H++x/UI0QKBgQC4o8Jnhho8fl9rr1xpR809X9QcxMrwIcQ1\nfkCSQNpoPObXX+1negOOqIFGtI06i7uFMWwb2VdDlHRyIHR+vvbaxbdpmukivp7K\nbpP1djAAQ8bpF2XZV+qnhvVXrGzc7VD9dLUaj8vssppIdmWW1Xetj76WE05x+TUi\nFkLzQvYugQKBgAs9FZPbGrJ3rdvdSi6WfE911Q2BX3873fT94N/l6jvwKaOeqVIn\nfFB0Qaio7o5ajgZz2CnZg/qbqLPATd26LeCxLT4eowZgv326qxNBtCeV1F8fdQDw\nPGMHE+KlTJ4xqaIIid347wL1qT9/pGxX/yvw/uI1Mww0WETrADf/yRGRAoGABMFz\nCGeT1WsL2iIyJyQKTUJinDsVXwn/m8EcuKei+HxZFcMKwleKL+p3KfMMkC15Lv0O\n48i9TqhMN4ROe9U/VnMxPi8XQiXWwTAH75KTue4E+Yv4u5hgGuCHATMXurkCFQUk\nhQKfJgGTp7ok87Wb14SUTBlDM/xPOgmIv+tBnAECgYEAjvKPbnDTHPJrdU7Idv2u\nzv40uG7u2ovp1/a8u5z0ggfv5NeVewP4KRgXTcCYN9439OgeL86rFqv+JZ9ZpQrB\nWPXTUBYnDmEuKW3cmEwESrqTrqlox8gj4G+EibCtXeN2RwwUjXed38tcy6iFBkRA\nqzfMkI3lkHnja6PP2xxO2KA=\n-----END PRIVATE KEY-----\n",
  "client_email": "testbot@testbot-38d85.iam.gserviceaccount.com",
  "client_id": "117784101287290343302",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/testbot%40testbot-38d85.iam.gserviceaccount.com"}; 

// Set up Google Calendar Service account credentials
const serviceAccountAuth = new google.auth.JWT({
  email: serviceAccount.client_email,
  key: serviceAccount.private_key,
  scopes: 'https://www.googleapis.com/auth/calendar'
});

const calendar = google.calendar('v3');


const timeZone = 'Asia/Kolkata';
const timeZoneOffset = '+05:30';



 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 
  function hours (agent) {
    console.log("are we open ?")
    if (currentlyOpen()) {
      agent.add("We're open now! We close at 5pm today.");
    } else {
      agent.add("We're currently closed, but we open every weekday at 9am!");
    }
  }

  function makeAppointment (agent) {
    // Calculate appointment start and end datetimes (end = +1hr from start)
    console.log("make appointment")
    const dateTimeStart = new Date(Date.parse(agent.parameters.date.split('T')[0] + 'T' + agent.parameters.time.split('T')[1].split('-')[0] + timeZoneOffset));
    const dateTimeEnd = new Date(new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1));
    const appointmentTimeString = dateTimeStart.toLocaleString(
      'en-US',
      { month: 'long', day: 'numeric', hour: 'numeric', timeZone: timeZone }
    );

    // Check the availibility of the time, and make an appointment if there is time on the calendar
    return createCalendarEvent(dateTimeStart, dateTimeEnd).then(() => {
      agent.add("Ok, let me see if we can accomodate you in. ${appointmentTimeString} is fine!. Do you need a loan or just a credit card?");
    }).catch(() => {
      agent.add("I'm sorry, there are no slots available for ${appointmentTimeString}.");
    });
  }
 
  function welcome(agent) {
    agent.add(`Welcome to my agent!`);
  }
 
  function fallback(agent) {
    agent.add(`I didn't understand`);
    agent.add(`I'm sorry, can you try again?`);
}

  // // Uncomment and edit to make your own intent handler
  // // uncomment `intentMap.set('your intent name here', yourFunctionHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
   function yourFunctionHandler(agent) {
     agent.add(`This message is from Dialogflow's Cloud Functions for Firebase editor!`);
     agent.add(new Card({
         title: `Title: this is a card title`,
         imageUrl: 'https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png',
         text: `This is the body text of a card.  You can even use line\n  breaks and emoji! 💁`,
         buttonText: 'This is a button',
         buttonUrl: 'https://assistant.google.com/'
       })
     );
     agent.add(new Suggestion(`Quick Reply`));
     agent.add(new Suggestion(`Suggestion`));
     
     agent.setContext({ name: 'weather', lifespan: 2, parameters: { address: 'Rome' }});
   }

  // // Uncomment and edit to make your own Google Assistant intent handler
  // // uncomment `intentMap.set('your intent name here', googleAssistantHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function googleAssistantHandler(agent) {
  //   let conv = agent.conv(); // Get Actions on Google library conv instance
  //   conv.ask('Hello from the Actions on Google client library!') // Use Actions on Google library
  //   agent.add(conv); // Add Actions on Google library responses to your agent's response
  // }
  // // See https://github.com/dialogflow/dialogflow-fulfillment-nodejs/tree/master/samples/actions-on-google
  // // for a complete Dialogflow fulfillment library Actions on Google client library v2 integration sample

  function cityWeather (agent) {
    // Create the path for the HTTP request to get the weather
    //https://samples.openweathermap.org/data/2.5/weather?q=London&appid=b6907d289e10d714a6e88b30761fae22
    let city = 'London'
    let path = '/data/2.5/weather?' +
      'q=' + encodeURIComponent(city) + '&appid=' + wwoApiKey;
    console.log('API Request: ' + host + path);

    // Make the HTTP request to get the weather
    https.get({host: host, path: path}, (res) => {
      let body = 'hello'; // var to store the response chunks
      console.log(body);
      res.on('data', (d) => { body += d; 
          console.log(body);
      }); // store each response chunk
      res.on('end', () => {
        //agent.add(new Text(body));
        // After all the data has been received parse the JSON for desired data
        /*let response = JSON.parse(body);
        let forecast = response['data']['weather'][0];
        let location = response['data']['request'][0];
        let conditions = response['data']['current_condition'][0];
        let currentConditions = conditions['weatherDesc'][0]['value'];

        // Create response
        let output = `Current conditions in the ${location['type']} 
        ${location['query']} are ${currentConditions} with a projected high of
        ${forecast['maxtempC']}°C or ${forecast['maxtempF']}°F and a low of 
        ${forecast['mintempC']}°C or ${forecast['mintempF']}°F on 
        ${forecast['date']}.`;
        */
        // Resolve the promise with the output text
        console.log(body);
      });
      res.on('error', (error) => {
        console.log(`Error calling the weather API: ${error}`)
      });
    });
    
  }   
    
    function getOTP(agent) {
    // Create the path for the HTTP request to get the weather
    //https://samples.openweathermap.org/data/2.5/weather?q=London&appid=b6907d289e10d714a6e88b30761fae22
    let host = '2factor.in';
    let phonenumber = agent.parameters['phone-number'];
    let apiKey = 'db36cc5a-ec41-11e8-a895-0200cd936042';
    let sessionId = null;
    let path = '/API/V1/' + apiKey + '/SMS/'+ '+91'+ phonenumber + '/AUTOGEN';
    console.log('API Request: ' + host + path);

    // Make the HTTP request to get the weather
    https.get({host: host, path: path}, (res) => {
      let body = ''; // var to store the response chunks
      console.log(body);
      res.on('data', (d) => { body += d; 
          console.log(body);
      }); // store each response chunk
      res.on('end', () => {
        //agent.add(new Text(body));
        // After all the data has been received parse the JSON for desired data
        /*let response = JSON.parse(body);
        let forecast = response['data']['weather'][0];
        let location = response['data']['request'][0];
        let conditions = response['data']['current_condition'][0];
        let currentConditions = conditions['weatherDesc'][0]['value'];

        // Create response
        let output = `Current conditions in the ${location['type']} 
        ${location['query']} are ${currentConditions} with a projected high of
        ${forecast['maxtempC']}°C or ${forecast['maxtempF']}°F and a low of 
        ${forecast['mintempC']}°C or ${forecast['mintempF']}°F on 
        ${forecast['date']}.`;
        */
        // Resolve the promise with the output text
        console.log(body);
      });
      res.on('error', (error) => {
        console.log(`Error calling the weather API: ${error}`)
      });
    });
  
}

  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('weather', yourFunctionHandler);
  intentMap.set('getOTP', getOTP);
  intentMap.set('Hours', hours);
  intentMap.set('Make Appointment', makeAppointment);
  // intentMap.set('your intent name here', googleAssistantHandler);
  agent.handleRequest(intentMap);
});


function currentlyOpen () {
  // Get current datetime with proper timezone
  let date = new Date();
  date.setHours(date.getHours() + parseInt(timeZoneOffset.split(':')[0]));
  date.setMinutes(date.getMinutes() + parseInt(timeZoneOffset.split(':')[0][0] + timeZoneOffset.split(':')[1]));

  return date.getDay() >= 1 &&
        date.getDay() <= 5 &&
        date.getHours() >= 9 &&
        date.getHours() <= 17;
}

function createCalendarEvent (dateTimeStart, dateTimeEnd) {
  return new Promise((resolve, reject) => {
    calendar.events.list({
      auth: serviceAccountAuth, // List events for time period
      calendarId: calendarId,
      timeMin: dateTimeStart.toISOString(),
      timeMax: dateTimeEnd.toISOString()
    }, (err, calendarResponse) => {
      // Check if there is a event already on the Bike Shop Calendar
      if (err || calendarResponse.data.items.length > 0) {
        reject(err || new Error('Requested time conflicts with another appointment'));
      } else {
        // Create event for the requested time period
        calendar.events.insert({ auth: serviceAccountAuth,
          calendarId: calendarId,
          resource: {summary: 'Customer Appointment',
            start: {dateTime: dateTimeStart},
            end: {dateTime: dateTimeEnd}}
        }, (err, event) => {
          err ? reject(err) : resolve(event);
        }
        );
      }
    });
  });
}
